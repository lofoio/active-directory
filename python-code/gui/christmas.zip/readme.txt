These icons are from Icojam (http://www.icojam.com)

Cristmas icons

Ammount of icons:
28

Icon Sizes:
50x50

File Types:
.gif (indexed)
.png (RGBA)

Versions without shadows are included

Note: These icons are free to use in any kind of project unlimited times